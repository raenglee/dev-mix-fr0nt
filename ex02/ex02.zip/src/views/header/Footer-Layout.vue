<template>
  <!-- <div class="bg-[#d10000] w-full text-white text-center bottom-0 left-0">DEVMIX
    <br>푸터<br> 내용<br>
  </div> -->

  <div class="bg-[#d10000] w-full text-white p-4 px-72 mt-8 text-center">
    <p class="font-bold">DEVMIX</p>
    <div class="text-sm py-2">
      <p class="mb-1">주소: 대구광역시 중구 중앙대로 394 제일빌딩 505호</p>
      <div class="flex gap-1 text-sm justify-center mb-1">
        <p>대표: 정세엽 |</p>
        <p>공동 대표: 이상진 김재형 김채언 이주현</p>
      </div>
      <p>전화번호: 053-572-1005</p>
    </div>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
