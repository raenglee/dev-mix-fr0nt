<template>
  <!-- <div class="bg-[#d10000] w-full text-white text-center bottom-0 left-0">DEVMIX
    <br>푸터<br> 내용<br>
  </div> -->

  <div class="bg-[#d10000] w-full text-white text-center py-3 mt-10">
      DEVMIX
      <br>푸터<br> 내용<br>
    </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
